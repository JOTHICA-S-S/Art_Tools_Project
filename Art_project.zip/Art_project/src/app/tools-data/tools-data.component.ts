import { Component } from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-tools-data',
  templateUrl: './tools-data.component.html',
  styleUrls: ['./tools-data.component.css']
})
export class ToolsDataComponent {
  
  public toolId:any;
  public toolImage:any;
  public toolProduct:any;
  public toolCost:any;
  public toolBrand:any;
  public toolNoOfItems:any;
  public toolMadeIn:any;
  public toolInStock:any;
  public toolDescription:any;

  constructor (private route:ActivatedRoute){}
  ngOnInit()
  {
    let id=this.route.snapshot.paramMap.get('id');
    this.toolId=id;

    let image=this.route.snapshot.paramMap.get('image');
    this.toolImage=image;

    let name=this.route.snapshot.paramMap.get('product');
    this.toolProduct=name;

    let price=this.route.snapshot.paramMap.get('cost');
    this.toolCost=price;

    let brand=this.route.snapshot.paramMap.get('brand');
    this.toolBrand=brand;

    let noOfItems=this.route.snapshot.paramMap.get('noOfItems');
    this.toolNoOfItems=noOfItems;

    let madeIn=this.route.snapshot.paramMap.get('madeIn');
    this.toolMadeIn=madeIn;

    let inStock=this.route.snapshot.paramMap.get('inStock');
    this.toolInStock=inStock;

    let description=this.route.snapshot.paramMap.get('description');
    this.toolDescription=description;
  }

}
