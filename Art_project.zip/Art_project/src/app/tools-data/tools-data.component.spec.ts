import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolsDataComponent } from './tools-data.component';

describe('ToolsDataComponent', () => {
  let component: ToolsDataComponent;
  let fixture: ComponentFixture<ToolsDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ToolsDataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ToolsDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
