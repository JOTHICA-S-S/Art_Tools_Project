import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArtToolsComponent } from './art-tools/art-tools.component';
import { ToolsDataComponent } from './tools-data/tools-data.component';

const routes: Routes = [
  {path: '', redirectTo: '/', pathMatch: 'full'},
  {path:'tools',component:ArtToolsComponent},
  {path:'toolsdata/:image/:product/:cost/:brand/:noOfItems/:madeIn/:Instock/:description',component:ToolsDataComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
