import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtToolsComponent } from './art-tools.component';

describe('ArtToolsComponent', () => {
  let component: ArtToolsComponent;
  let fixture: ComponentFixture<ArtToolsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArtToolsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ArtToolsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
