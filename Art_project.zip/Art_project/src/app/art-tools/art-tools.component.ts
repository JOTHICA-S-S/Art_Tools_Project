import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ServiceService } from '../shared/service.service';
import { toolsModel } from './art-tools-dashboard-model';
import {Router} from '@angular/router';

@Component({
  selector: 'app-art-tools',
  templateUrl: './art-tools.component.html',
  styleUrls: ['./art-tools.component.css']
})
export class ArtToolsComponent implements OnInit {
  

  formValue !: FormGroup;
  toolsModelObj: toolsModel = new toolsModel();
  ToolsData: any;
  showAdd !:boolean;
  showUpdate !:boolean;
  showDetails !:boolean;
  
  

  constructor(private formBuilder: FormBuilder, 
    private api: ServiceService,private router:Router) { }

    ngOnInit() {

      this.router.routeReuseStrategy.shouldReuseRoute = () => false;
      //group is a method that receives object as parameter
      this.formValue = this.formBuilder.group({
        image:[''],product: [''], cost: [''], brand: [''], noOfItems: [''], madeIn: [''],inStock:[''],description:['']
      })
      this.getAllTools();
    }

   
    fetchTool(tool:any)
    {
      this.router.navigate(['/toolsdata',tool.image,tool.product,tool.cost,tool.brand,tool.noOfItems,tool.madeIn,tool.inStock,tool.description ]);
      this.showDetails=true;
    }

   

    getAllTools(){
      this.api.getAllTools().subscribe(
        res=>{
          this.ToolsData=res;
        })
    }

    clickAddTool()
  {
    this.formValue.reset();
    this.showAdd=true;
    this.showUpdate=false;
  }

    postToolDetails() {
      this.toolsModelObj.image = this.formValue.value.image;
      this.toolsModelObj.product = this.formValue.value.product;
      this.toolsModelObj.cost = this.formValue.value.cost;
      this.toolsModelObj.brand = this.formValue.value.brand;
      this.toolsModelObj.noOfItems = this.formValue.value.noOfItems;
      this.toolsModelObj.madeIn = this.formValue.value.madeIn;
      this.toolsModelObj.inStock = this.formValue.value.inStock;
      this.toolsModelObj.description = this.formValue.value.description;
  
      this.api.postTools(this. toolsModelObj).subscribe(
        res => {
          console.log(res);
          alert("Tool added succesfully !!!");
          this.getAllTools();
          let close = document.getElementById("cancel");
          close?.click();
          this.formValue.reset();
        },
        err => {
          alert("Something went wrong!!!");//used to handle the error
        })
    }

    deleteTool(emp:any)
      {
        this.api.deleteTool(emp.id).subscribe(
          res =>{
            alert("Tool Deleted");
            this.getAllTools();
          }
        ) 
      }

      editTool(data:any)
      {
        this.toolsModelObj.id=data.id;
        this.showUpdate=true;
        this.showAdd=false;
        this.formValue.controls['image'].setValue(data.image);
        this.formValue.controls['product'].setValue(data.product);
        this.formValue.controls['cost'].setValue(data.cost);
        this.formValue.controls['brand'].setValue(data.brand);
        this.formValue.controls['noOfItems'].setValue(data.noOfItems);
        this.formValue.controls['madeIn'].setValue(data.madeIn);
        this.formValue.controls['inStock'].setValue(data.inStock);
        this.formValue.controls['description'].setValue(data.description);
      }
  
      updateTool()
      {
        this.toolsModelObj.image = this.formValue.value.image;
        this.toolsModelObj.product = this.formValue.value.product;
        this.toolsModelObj.cost = this.formValue.value.cost;
        this.toolsModelObj.brand = this.formValue.value.brand;
        this.toolsModelObj.noOfItems = this.formValue.value.noOfItems;
        this.toolsModelObj.madeIn = this.formValue.value.madeIn;
        this.toolsModelObj.inStock = this.formValue.value.inStock;
        this.toolsModelObj.description = this.formValue.value.description;

        this.api.updateTool(this.toolsModelObj,this.toolsModelObj.id).subscribe(
          res => {
            console.log(res);
            alert("Tool updated succesfully !!!");
            this.getAllTools();
            let close = document.getElementById("cancel");
            close?.click();
            this.formValue.reset();
            
          },
          err => {
            alert("Something went wrong!!!");//used to handle the error
            
          })
      }
}
