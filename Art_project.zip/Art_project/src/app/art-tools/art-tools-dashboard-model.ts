export class toolsModel
{
    id:number=0;
    image:string='';
    product:string='';
    cost:string='';
    brand:string='';
    noOfItems:string='';
    madeIn:string='';
    inStock:string='';
    description:string='';
}